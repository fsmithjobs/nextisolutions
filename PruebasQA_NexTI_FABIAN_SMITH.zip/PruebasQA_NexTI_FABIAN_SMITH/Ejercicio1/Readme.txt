# Ejercicio 1 - Prueba Automatizada con Serenity BDD

Este proyecto tenía como objetivo configurar y ejecutar una prueba automatizada de un flujo de compra utilizando Serenity BDD con JUnit. A continuación, se presentan los pasos que se siguieron para intentar ejecutar la prueba.

## Requisitos previos
- Tener instalado Java 11 o superior.
- Maven instalado y configurado en la variable de entorno PATH.
- Un IDE, como IntelliJ IDEA o Eclipse, para abrir y editar el proyecto.

## Instrucciones paso a paso

1. **Clonar o crear el proyecto en un entorno de Maven**
   - Inicializa un nuevo proyecto de Maven o clona el proyecto existente en tu máquina local.

2. **Configurar el archivo `pom.xml`**
   - Se añadieron las dependencias necesarias para el ejercicio:
     - Selenium WebDriver para la interacción con el navegador.
     - Serenity BDD para la gestión de pruebas y generación de reportes.
     - JUnit4 para ejecutar la prueba con SerenityRunner.

3. **Crear las clases de prueba**
   - En `E2ETest.java`, se implementó la clase de prueba para el flujo de compra.
   - Se utilizó `SerenityRunner` para que Serenity gestione la prueba.

4. **Ejecutar la prueba**
   - Abre una terminal en el directorio del proyecto y ejecuta:
     ```bash
     mvn clean test
     ```
   - Este comando debería limpiar el proyecto, compilarlo y ejecutar las pruebas automatizadas.

5. **Verificar los resultados**
   - Después de la ejecución, los resultados de las pruebas se generan en `target/surefire-reports` y los reportes de Serenity en `target/site/serenity`.

## Problemas encontrados

Durante la ejecución de este ejercicio, surgieron múltiples problemas de configuración y vulnerabilidades en dependencias transitivas. Algunos de los errores incluyeron:
- Errores de resolución de dependencias para `SerenityJUnit5` y `SerenityRunner`.
- Múltiples vulnerabilidades de seguridad en dependencias transitivas, como `Netty`, `Bouncycastle`, y `Commons Compress`.

A pesar de varios intentos para corregir las configuraciones, no se logró ejecutar satisfactoriamente la prueba.

