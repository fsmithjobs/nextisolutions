import net.serenitybdd.junit.runners.SerenityRunner;
import net.thucydides.core.annotations.Steps;
import org.junit.Test;
import org.junit.runner.RunWith;
import steps.PurchaseSteps;

@RunWith(SerenityRunner.class)
public class E2ETest {

    @Steps
    PurchaseSteps purchaseSteps;

    @Test
    public void realizarFlujoDeCompra() {
        purchaseSteps.agregarProductosAlCarrito();
        purchaseSteps.irAlCarrito();
        purchaseSteps.checkoutComoInvitado();
        purchaseSteps.confirmarPedido();
    }
}
