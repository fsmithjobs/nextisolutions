package steps;

import net.thucydides.core.annotations.Step;
import pages.CartPage;
import pages.HomePage;

public class PurchaseSteps {

    HomePage homePage;
    CartPage cartPage;

    @Step("Agregar productos al carrito")
    public void agregarProductosAlCarrito() {
        homePage.open();
        homePage.agregarPrimerProductoAlCarrito();
        homePage.agregarPrimerProductoAlCarrito();
    }

    @Step("Ir al carrito")
    public void irAlCarrito() {
        homePage.irAlCarrito();
    }

    @Step("Hacer checkout como invitado")
    public void checkoutComoInvitado() {
        cartPage.hacerCheckoutComoInvitado();
    }

    @Step("Confirmar pedido")
    public void confirmarPedido() {
        cartPage.confirmarPedido();
    }
}
