package pages;

import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;

public class HomePage extends PageObject {

    private final By firstProductAddButton = By.xpath("//div[@class='product-thumb']//button[contains(@onclick,'cart.add')]");
    private final By shoppingCartLink = By.linkText("Shopping Cart");

    public void agregarPrimerProductoAlCarrito() {
        $(firstProductAddButton).click();
    }

    public void irAlCarrito() {
        $(shoppingCartLink).click();
    }
}
