package pages;

import net.serenitybdd.core.pages.PageObject;
import org.openqa.selenium.By;

public class CartPage extends PageObject {

    public void hacerCheckoutComoInvitado() {
        $(By.linkText("Checkout")).click(); // Ir a la página de checkout
        $(By.id("button-account")).click(); // Seleccionar "Guest Checkout"
        $(By.id("button-guest")).click();

        // Completar el formulario de información de invitado
        $(By.id("input-payment-firstname")).type("John");
        $(By.id("input-payment-lastname")).type("Doe");
        $(By.id("input-payment-email")).type("johndoe@example.com");
        $(By.id("input-payment-telephone")).type("1234567890");
        $(By.id("input-payment-address-1")).type("123 Test St");
        $(By.id("input-payment-city")).type("TestCity");
        $(By.id("input-payment-postcode")).type("12345");
        $(By.id("input-payment-country")).selectByVisibleText("United States");
        $(By.id("input-payment-zone")).selectByVisibleText("California");

        // Proceder al siguiente paso
        $(By.id("button-guest")).click();
        $(By.id("button-shipping-method")).click(); // Confirmar método de envío
        $(By.name("agree")).click(); // Aceptar términos y condiciones
    }

    public void confirmarPedido() {
        $(By.id("button-confirm")).click();
        // Validar que el pedido se ha realizado correctamente
        $(By.xpath("//*[contains(text(),'Your order has been placed!')]")).waitUntilVisible();
    }
}
