package tests;

import net.serenitybdd.junit5.SerenityJUnit5;
import net.thucydides.core.annotations.Steps;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import steps.PurchaseSteps;

@ExtendWith(SerenityJUnit5.class)
public class E2ETest {

    @Steps
    PurchaseSteps purchaseSteps;

    @Test
    public void realizarFlujoDeCompra() {
        purchaseSteps.agregarProductosAlCarrito();
        purchaseSteps.irAlCarrito();
        purchaseSteps.checkoutComoInvitado();
        purchaseSteps.confirmarPedido();
    }
}
