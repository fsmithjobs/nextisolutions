package tests;

import com.intuit.karate.junit5.Karate;

class RunTests {

    @Karate.Test
    Karate testAll() {
        return Karate.run("petstoreTest").relativeTo(getClass());
    }
}
