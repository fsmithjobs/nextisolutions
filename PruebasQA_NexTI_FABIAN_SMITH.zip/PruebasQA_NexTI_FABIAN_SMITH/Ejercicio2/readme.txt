
# Ejercicio de Pruebas API PetStore

Estas pruebas verifican los endpoints de creación, consulta, actualización y búsqueda de mascotas en la tienda.

### Requerimientos

1. **Java 11** o superior.
2. **Maven 3.6** o superior.
3. **Karate Framework** para ejecutar pruebas de API REST.

### Pasos para la Ejecución

1. **Clonar el repositorio**:
   Clona este repositorio en tu máquina local para tener acceso a todos los archivos necesarios, incluyendo el código fuente y el archivo `pom.xml`.

   ```bash
   git clone <URL-del-repositorio>
   cd Ejercicio2
   ```

2. **Instalar dependencias**:
   Navega a la carpeta del proyecto y ejecuta el siguiente comando para instalar las dependencias necesarias a través de Maven:

   ```bash
   mvn clean install
   ```

3. **Ejecutar las pruebas**:
   Para correr las pruebas, ejecuta el siguiente comando desde la terminal:

   ```bash
   mvn test
   ```

4. **Verificar resultados**:
   Los resultados de las pruebas se generarán automáticamente en la carpeta `target/karate-reports`. Abre el archivo `karate-summary.html` para ver el resumen de ejecución.

5. **Verificar Logs y Resultados Detallados**:
   Además, en la carpeta `target/surefire-reports` se generan archivos de resultados detallados en formato XML y de texto, útiles para revisión adicional.

### Escenarios Cubiertos

- **Añadir una mascota a la tienda**: Agrega una nueva mascota con ID y estatus específicos.
- **Consultar la mascota ingresada**: Valida que la mascota añadida se puede recuperar por ID.
- **Actualizar el nombre y estatus de la mascota**: Cambia el nombre y el estado de la mascota a "sold".
- **Consultar la mascota por estatus**: Verifica que la mascota actualizada se puede buscar correctamente por su nuevo estatus.
